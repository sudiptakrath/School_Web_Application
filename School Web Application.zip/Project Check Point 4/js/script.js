// Login Page Section ---
let studentuser = [];
function fetchStudentData() {
  fetch("student.json")
    .then((response) => response.json())
    .then((json) => {
      console.log(json);
      studentuser = JSON.parse(JSON.stringify(json));
      console.log(studentuser);
      console.log(studentuser.student[0]);
      console.log(studentuser.student[0].username);
      studentuser = JSON.parse(JSON.stringify(json)).student;
      console.log(studentuser[0].username);
      console.log(studentuser.length);
    });
}
fetchStudentData();

function login() {
  fetch("student.json")
    .then((response) => response.json())
    .then((json) => {
      studentuser = JSON.parse(JSON.stringify(json)).student;
      callLogin();
    });
}
function callLogin() {
  let user = document.getElementById("username").value;
  let pass = document.getElementById("password").value;
  let validuser = false;
  for (let i = 0; i < studentuser.length; i++) {
    if (studentuser[i].username == user && studentuser[i].password == pass) {
      validuser = true;
      sessionStorage.setItem("studId", studentuser[i].id);
      sessionStorage.setItem("username", studentuser[i].username);
      break;
    }
  }
  if (validuser) {
    window.location.href = "../WelcomePage.html";
  } else {
    document.getElementById("loginError").style.display = "block";
  }
}
function hideLoginError() {
  document.getElementById("loginError").style.display = "none";
}

// Exam Result Section ---
function displayExamResults() {
  fetch("student.json")
    .then((response) => response.json())
    .then((json) => {
      studentuser = JSON.parse(JSON.stringify(json)).student;
      ExamMarks();
    });
}
function ExamMarks() {
  let subject = document.getElementById("subject").value;
  let marks = document.getElementById("marks");
  let grade = document.getElementById("grade");

  marks.value = "";
  grade.value = "";
  for (let i = 0; i < studentuser.length; i++) {
    if (studentuser[i].id == sessionStorage.getItem("studId")) {
      for (const key in studentuser[i]) {
        if (studentuser[i].hasOwnProperty(key)) {
          if (subject == key) {
            marks.value = studentuser[i][key]["marks"];
            grade.value = studentuser[i][key]["grade"];
          }
        }
      }
    }
  }
}

// Extra Activities Section ---

// Add value in Activities Section
function addActivity() {
  let activityName = document.getElementById("activityname").value;
  let activityDetails = document.getElementById("activitybrief").value;
  sessionStorage.setItem(activityName, activityDetails);
  alert("Your Activity Submitted Successfully");
}

// // Display All Activities
function listActivity() {
  let listContainer = document.getElementById("activityList");
  if (sessionStorage.length < 4) {
    // For hiding the List of Extra Activities Section
    document.getElementById("actlist").style.display = "none";
  } else {
    //For showing the List of Extra Activities section
    document.getElementById("actlist").style.display = "block";

    for (let i = 0; i < sessionStorage.length; i++) {
      let key = sessionStorage.key(i);
      if (key != "username" && key != "IsThisFirstTime_Log_From_LiveServer") {
        let activityName = document.createElement("dt");
        activityName.innerHTML = key;
        activityList.appendChild(activityName);

        let activityDetails = document.createElement("dd");
        activityDetails.innerHTML = sessionStorage.getItem(key);
        activityList.appendChild(activityDetails);
      }
    }
  }
  // For clear all activities
  // sessionStorage.clear();
}

// Profile Details

function profileDetails() {
  fetch("student.json")
    .then((response) => response.json())
    .then((json) => {
      studentuser = JSON.parse(JSON.stringify(json)).student;
      ProfileInfo();
    });
}
function ProfileInfo() {
  for (let i = 0; i < studentuser.length; i++) {
    if (studentuser[i].id == sessionStorage.getItem("studId")) {
      for (const key in studentuser[i]) {
        if (studentuser[i].hasOwnProperty(key)) {
          if (key == "username") {
            document.getElementById("name").innerHTML = studentuser[i][key];
          } else if (key == "roll") {
            document.getElementById("roll").innerHTML = studentuser[i][key];
          } else if (key == "bldg") {
            document.getElementById("bldg").innerHTML = studentuser[i][key];
          } else if (key == "email") {
            document.getElementById("email").innerHTML = studentuser[i][key];
          } else if (key == "phns") {
            document.getElementById("phns").innerHTML = studentuser[i][key];
          } else if (key == "adss") {
            document.getElementById("adss").innerHTML = studentuser[i][key];
          } else if (key == "fname") {
            document.getElementById("fname").innerHTML = studentuser[i][key];
          } else if (key == "femail") {
            document.getElementById("femail").innerHTML = studentuser[i][key];
          } else if (key == "mname") {
            document.getElementById("mname").innerHTML = studentuser[i][key];
          } else if (key == "memail") {
            document.getElementById("memail").innerHTML = studentuser[i][key];
          } else if (key == "phnp") {
            document.getElementById("phnp").innerHTML = studentuser[i][key];
          } else if (key == "adsp") {
            document.getElementById("adsp").innerHTML = studentuser[i][key];
          } else if (key == "dobs") {
            document.getElementById("dobs").innerHTML = studentuser[i][key];
          }
        }
      }
    }
  }
}
